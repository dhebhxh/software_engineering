class Level1 {
    constructor() {
        this.entities = [];
        this.entities.push(new Home());
        this.entities.push(new Player());
        this.entities.push(new Platform());
        this.entities.push(new Platform());
        this.physicsSystem(this.entities);
    }
    updatePhysics() {

    }
    updateCollision() {

    }
    updateDraw() {
        
    }
    destory(){
        //asdfasdfasdf
    }
}